package com.hanif.tugasdua;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button btnLogin;
    EditText edNpm;
    EditText edNama;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        edNpm =(EditText) findViewById(R.id.edNpm);
        edNama = (EditText) findViewById(R.id.edNama);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String npm = edNpm.getText().toString();
                String nama = edNama.getText().toString();

                Intent a = new Intent(MainActivity.this,Main2Activity2.class);
                a.putExtra("npm", npm);
                a.putExtra("nama", nama);
                startActivity(a);
                finish();
            }
        });
    }
}
